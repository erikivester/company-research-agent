# Airtable Extension Export - Deployment Package# AI Email Generator - Airtable Custom Extension



This package contains all files needed to deploy the AI Email Generator Airtable Extension to Google Cloud Platform independently.A powerful Airtable custom extension that generates personalized outreach emails using AI, combining templates from Google Drive with research context and Airtable data.



## 📁 Package Contents## Features



```✨ **Visual Interface** - Easy-to-use UI with record selection and template management

airtable-extension-export/🎯 **Dynamic Templates** - Fetch and sync templates directly from Google Drive

├── frontend/              # React frontend code🤖 **AI-Powered** - Generate personalized emails using OpenAI GPT-4

│   ├── index.js          # Main entry point📊 **Batch Processing** - Generate emails for multiple records at once

│   └── ...               # Components and assets🔄 **Template Sync** - Keep Airtable field options synchronized with available templates

├── block.json            # Airtable extension configuration⚙️ **Configurable** - Flexible field mapping for any base structure

├── package.json          # Node.js dependencies and scripts📈 **Progress Tracking** - Real-time progress indicators for batch operations

├── server.js             # Express server for production

├── app.yaml              # Google App Engine configuration## Screenshots

├── Dockerfile            # Container configuration for Cloud Run

├── .gcloudignore         # Files to exclude from deployment### Main Interface

├── DEPLOYMENT.md         # Detailed deployment instructions- Record selection with visual cards

└── README.md            # This file- Template dropdown or field-based selection

```- Batch email generation with progress tracking



## 🚀 Quick Start - Deploy to Google Cloud### Settings Panel

- API endpoint configuration

### Option 1: Google App Engine (Recommended)- Table and field mapping

- Template field setup

```bash

# 1. Install Google Cloud SDK## Installation

# Download from: https://cloud.google.com/sdk/docs/install

### Prerequisites

# 2. Initialize project

gcloud init1. **Airtable Blocks CLI** installed:

gcloud config set project YOUR_PROJECT_ID   ```bash

   npm install -g @airtable/blocks-cli

# 3. Install dependencies   ```

npm install

2. **FastAPI Server** running with endpoints:

# 4. Deploy   - `GET /templates` - List available templates

gcloud app deploy   - `POST /generate-outreach` - Generate emails



# 5. Get your URL3. **Ngrok** tunnel (for development) or production URL

gcloud app browse

```### Setup Steps



Your extension will be available at: `https://YOUR_PROJECT_ID.uc.r.appspot.com`1. **Navigate to the extension directory**:

   ```bash

### Option 2: Google Cloud Run (More flexible)   cd scripting

   ```

```bash

# 1. Build and push container2. **Install dependencies**:

gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/airtable-extension   ```bash

   npm install

# 2. Deploy   ```

gcloud run deploy airtable-extension \

  --image gcr.io/YOUR_PROJECT_ID/airtable-extension \3. **Initialize the extension** (first time only):

  --platform managed \   ```bash

  --region us-central1 \   block run

  --allow-unauthenticated \   ```

  --port 9000

4. **Open in Airtable**:

# 3. Get your URL (returned in output)   - The extension will open in your browser

```   - Click "Add extension to base" if prompted



## 🔧 Configuration5. **Configure settings**:

   - Click the settings (⚙️) button

### Update API Endpoint   - Set your API endpoint

   - Map fields to your base structure

Edit `frontend/index.js` to point to your backend API:

## Configuration

```javascript

const API_ENDPOINT = 'https://your-backend-api.com';### Required Fields

```

Your Airtable base should have these fields (names can be customized):

### Environment Variables

| Field | Type | Purpose |

Set via `app.yaml`:|-------|------|---------|

| Contact Name | Single line text | Name of the person to email |

```yaml| Company Name | Single line text | Company name |

env_variables:| Contact Title | Single line text | Contact's job title |

  API_ENDPOINT: "https://your-api.com"| Company Summary | Long text | Brief company overview |

  NODE_ENV: "production"| Angle for Outreach | Long text | Strategic notes |

```| Note | Long text | Additional context |

| Research Folder URL | URL | Google Drive folder with research |

Or via gcloud command:| Email Draft | Long text | Where generated email is saved |

| Template Type | Single select | (Optional) Dynamic template selection |

```bash

gcloud app deploy --set-env-vars API_ENDPOINT=https://your-api.com### API Endpoint

```

Default: `https://futuramic-nonglandulous-senaida.ngrok-free.dev`

## 📝 Using the Extension in Airtable

Update this in Settings to match your:

1. **Open your Airtable base**- Ngrok tunnel URL (development)

2. **Click Extensions** (puzzle icon)- Production server URL

3. **Add an extension** → "Build a custom extension"- Localhost (if running in same network)

4. **Paste your deployed URL** (from step 5 above)

5. **Configure the extension** with your settings## Usage



## 💰 Cost Estimates### Basic Workflow



### Google App Engine1. **Open the extension** in your Airtable base

- **Free Tier**: 28 instance hours/day

- **F1 Instance**: ~$0.05/hour after free tier2. **Select records** - Click on record cards to select multiple records for batch processing

- **Scales to zero** when not in use

- **Estimated**: $0-15/month for typical usage3. **Choose template**:

   - **Manual**: Select from dropdown (if no Template Type field configured)

### Google Cloud Run   - **Dynamic**: Each record uses its own Template Type field value

- **Free Tier**: 2 million requests/month

- **Pay per use**: $0.00002400 per request4. **Click "Generate Email"** - The extension will:

- **Better for**: Variable traffic   - Fetch templates from API

- **Estimated**: $0-10/month for typical usage   - Pull research context from Google Drive

   - Generate personalized emails with AI

## 📚 See DEPLOYMENT.md for detailed instructions   - Save drafts to the Email Draft field



For complete deployment guide, troubleshooting, and advanced configuration, see [DEPLOYMENT.md](./DEPLOYMENT.md)5. **Review drafts** - Check generated emails in your records


### Template Management

#### Refresh Templates
- Click "Refresh" to fetch latest templates from Google Drive
- Updates the dropdown with current options

#### Sync Template Field
- Click "Sync Field" to update your Template Type single select options
- Adds new templates from Drive
- Removes templates no longer available
- Preserves colors for existing options

### Batch Processing

Generate emails for multiple records:
1. Select multiple records (click each card)
2. All selected records will be processed
3. Progress bar shows real-time status
4. Success/error summary displayed when complete

## Advanced Features

### Dynamic Template Selection

Enable per-record template selection:

1. **Create field**: Add "Template Type" single select field
2. **Configure**: Map it in Settings → Template Type Field
3. **Sync**: Click "Sync Field" to populate options from API
4. **Use**: Each record can now use a different template

### Field Mapping Flexibility

The extension works with any base structure:
- All field mappings are configurable
- Use your existing field names
- Map only the fields you need

### Error Handling

The extension handles common errors gracefully:
- ❌ API connection failures
- ❌ Missing required fields
- ❌ Rate limiting
- ❌ Invalid templates

Error messages provide clear guidance for resolution.

## Development

### Local Development

1. **Start the extension**:
   ```bash
   cd scripting
   block run
   ```

2. **Make changes** to `frontend/index.js`

3. **Hot reload** - Changes appear automatically in Airtable

### File Structure

```
scripting/
├── frontend/
│   ├── index.js          # Main React component
│   └── style.css         # Styling
├── block.json            # Extension metadata
├── package.json          # Dependencies
└── .eslintrc.js         # Linting rules
```

### Key Components

**EmailGeneratorApp** - Main app with settings toggle
**SettingsPanel** - Configuration interface
**MainPanel** - Email generation interface

### API Integration

The extension makes two main API calls:

```javascript
// Fetch available templates
GET /templates
Response: { "TEMPLATE_NAME": "Description..." }

// Generate email
POST /generate-outreach
Body: {
  template_type: string,
  contact_name: string,
  airtable_context: { ... },
  google_drive_folder_url: string
}
Response: {
  email_text: string,
  template_used: string,
  context_used: { ... }
}
```

## Troubleshooting

### "Failed to fetch templates"

**Causes**:
- API server not running
- Ngrok tunnel down
- Wrong API endpoint in settings

**Fix**:
```bash
# Check server
curl -H "ngrok-skip-browser-warning: true" \
  YOUR_URL/templates

# Should return JSON with templates
```

### "API error: 422"

**Causes**:
- Missing required fields
- Invalid data format
- Template not found

**Fix**:
- Check all required fields have values
- Verify template name matches exactly
- Check API logs for details

### Template sync fails

**Causes**:
- Template field is not Single Select type
- Field locked or in use by views
- Permission issues

**Fix**:
- Ensure field type is "Single Select"
- Temporarily remove from filtered views
- Check you have edit permissions

### Records not showing

**Causes**:
- Table not selected in settings
- Field mappings incomplete

**Fix**:
- Go to Settings (⚙️)
- Select table
- Map all required fields

## Best Practices

### 1. Configure Before Use
- Set up all field mappings in Settings first
- Test with one record before batch processing
- Verify API endpoint is correct

### 2. Template Management
- Sync template field regularly (weekly or after adding templates)
- Use clear, descriptive template names
- Keep templates organized in Google Drive

### 3. Batch Processing
- Start with small batches (5-10 records)
- Monitor progress for errors
- Review generated emails before sending

### 4. Field Validation
- Ensure required fields have values
- Use views to filter ready-for-email records
- Validate research folder URLs are correct

## API Requirements

Your FastAPI server must provide:

### GET /templates
Returns available email templates from Google Drive.

**Headers**: 
- `ngrok-skip-browser-warning: true` (for ngrok)

**Response**:
```json
{
  "TEMPLATE_NAME_1": "Template description...",
  "TEMPLATE_NAME_2": "Another template..."
}
```

### POST /generate-outreach
Generates personalized email using AI.

**Headers**:
- `Content-Type: application/json`
- `ngrok-skip-browser-warning: true` (for ngrok)

**Body**:
```json
{
  "template_type": "TEMPLATE_NAME",
  "contact_name": "John Doe",
  "airtable_context": {
    "name": "Company Name",
    "title": "Job Title",
    "summary": "Company summary",
    "angle_for_outreach": "Strategic angle",
    "note": "Additional notes"
  },
  "google_drive_folder_url": "https://drive.google.com/..."
}
```

**Response**:
```json
{
  "email_text": "Generated email content...",
  "template_used": "TEMPLATE_NAME",
  "context_used": {
    "template": true,
    "research": true,
    "airtable": true
  }
}
```

## Comparison: Extension vs Automations

| Feature | Custom Extension | Automations |
|---------|-----------------|-------------|
| **UI** | ✅ Rich visual interface | ❌ No UI |
| **Batch processing** | ✅ Select multiple records | ❌ One at a time |
| **Real-time feedback** | ✅ Progress bars, status | ⚠️ Logs only |
| **Template preview** | ✅ See all templates | ❌ Text input only |
| **Field sync** | ✅ One-click sync | ⚠️ Separate script |
| **User interaction** | ✅ Interactive | ❌ Automatic |
| **Execution** | 🔵 Manual trigger | 🟢 Automatic |

**Use Extension when**: You want interactive control and visual feedback
**Use Automation when**: You want scheduled/automatic execution

## Updates & Maintenance

### Updating the Extension

```bash
# Pull latest changes
git pull origin main

# Install dependencies
cd scripting
npm install

# Deploy
block run
```

### Monitoring

Check for:
- API endpoint changes (update in Settings)
- New template additions (sync field)
- Base structure changes (remap fields)
- Error patterns in Airtable logs

## Support

### Documentation
- **Setup Guide**: `/AIRTABLE_AUTOMATION_SETUP.md`
- **Template Sync**: `/TEMPLATE_SYNC_GUIDE.md`
- **API Docs**: `/docs/API.md`

### Common Issues
1. API connection → Check server and ngrok
2. Field errors → Verify field mappings
3. Template issues → Refresh or sync templates

## License

MIT License - See LICENSE.md

## Credits

Built with:
- Airtable Blocks SDK
- React
- FastAPI
- OpenAI GPT-4

---

**Version**: 1.0.0
**Last Updated**: November 10, 2025
