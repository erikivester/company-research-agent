const express = require('express');
const path = require('path');
const https = require('https');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 9000;

// Serve static files from the frontend build directory
app.use(express.static(path.join(__dirname, 'frontend')));

// CORS headers for Airtable
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve the extension for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'frontend', 'index.html'));
});

// Start server
if (process.env.NODE_ENV === 'production') {
  // Production mode - HTTP only (App Engine handles HTTPS)
  app.listen(PORT, () => {
    console.log(`Extension server running on port ${PORT}`);
  });
} else {
  // Development mode - HTTPS with self-signed cert
  const options = {
    key: fs.readFileSync(path.join(__dirname, 'localhost-key.pem')),
    cert: fs.readFileSync(path.join(__dirname, 'localhost.pem'))
  };
  
  https.createServer(options, app).listen(PORT, () => {
    console.log(`Extension server running on https://localhost:${PORT}`);
  });
}
