# Airtable Extension - Google Cloud Deployment

This directory contains the Airtable extension ready for deployment to Google Cloud Platform.

## Files Included

- `frontend/` - React frontend code for the extension
- `block.json` - Airtable extension configuration
- `package.json` - Node.js dependencies
- `app.yaml` - Google App Engine configuration
- `server.js` - Express server to serve the extension

## Prerequisites

1. **Google Cloud SDK** - Install from: https://cloud.google.com/sdk/docs/install
2. **Node.js 20+** - Required for building the extension
3. **Google Cloud Project** - Create one at: https://console.cloud.google.com

## Deployment Steps

### 1. Initialize Google Cloud

```bash
# Login to Google Cloud
gcloud auth login

# Set your project ID
gcloud config set project YOUR_PROJECT_ID

# Enable App Engine
gcloud app create --region=us-central
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Build the Extension

```bash
# This will bundle your React app
npm run build
```

### 4. Deploy to Google App Engine

```bash
gcloud app deploy
```

### 5. Get Your Extension URL

After deployment, your extension will be available at:
```
https://YOUR_PROJECT_ID.uc.r.appspot.com
```

### 6. Configure Airtable

1. Open your Airtable base
2. Click Extensions → Add an extension
3. Choose "Build a custom extension"
4. Paste your Google App Engine URL
5. Configure your API endpoint in the extension settings

## Environment Variables

If your extension needs environment variables (like API keys), set them with:

```bash
gcloud app deploy --set-env-vars KEY=VALUE
```

Or add them to `app.yaml`:

```yaml
env_variables:
  API_ENDPOINT: "https://your-backend-api.com"
  API_KEY: "your-api-key"
```

## Updating the Extension

To update after making changes:

```bash
npm run build
gcloud app deploy
```

## Cost Management

Google App Engine F1 instances include:
- 28 instance hours per day (free tier)
- Pay only when extension is actively used
- Auto-scales to zero when idle

## Troubleshooting

### View Logs
```bash
gcloud app logs tail -s default
```

### Check Deployment Status
```bash
gcloud app versions list
```

### Rollback if Needed
```bash
gcloud app versions list
gcloud app services set-traffic default --splits=PREVIOUS_VERSION=1
```

## Alternative: Google Cloud Run

For more control and potentially lower costs, consider Cloud Run:

```bash
# Build container
gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/airtable-extension

# Deploy to Cloud Run
gcloud run deploy airtable-extension \
  --image gcr.io/YOUR_PROJECT_ID/airtable-extension \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated
```

## Support

- Google Cloud Documentation: https://cloud.google.com/appengine/docs
- Airtable Extensions: https://airtable.com/developers/extensions
